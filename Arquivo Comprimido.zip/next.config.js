module.exports = {
  reactStrictMode: false,
}
