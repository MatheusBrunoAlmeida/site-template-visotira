"use strict";
exports.id = 122;
exports.ids = [122];
exports.modules = {

/***/ 1138:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6099);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(reactstrap__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var _assets_images_staticslider_slider_hero_banner_jpg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9546);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
/* eslint-disable */







const BannerComponent = () => {
  return /*#__PURE__*/_jsx("div", {
    children: /*#__PURE__*/_jsx("div", {
      className: "static-slider10",
      children: /*#__PURE__*/_jsx(Container, {
        children: /*#__PURE__*/_jsxs(Row, {
          className: "",
          children: [/*#__PURE__*/_jsxs(Col, {
            md: "6",
            className: "align-self-center ",
            children: [/*#__PURE__*/_jsx("span", {
              className: "label label-rounded label-inverse",
              children: "Creating Brands"
            }), /*#__PURE__*/_jsx("h1", {
              className: "title",
              children: "ONE BILLON People Use Facebook"
            }), /*#__PURE__*/_jsx("h6", {
              className: "subtitle op-8",
              children: "Pellentesque vehicula eros a dui pretium ornare. Phasellus congue vel quam nec luctus.In accumsan at eros in dignissim. Cras sodales nisi nonn accumsan."
            }), /*#__PURE__*/_jsx("a", {
              className: "btn btn-light btn-rounded btn-md m-t-20",
              "data-toggle": "collapse",
              href: "",
              children: /*#__PURE__*/_jsx("span", {
                children: "Do you Need Help?"
              })
            })]
          }), /*#__PURE__*/_jsx(Col, {
            md: "6",
            children: /*#__PURE__*/_jsx(Image, {
              src: herobanner,
              alt: "herobanner"
            })
          })]
        })
      })
    })
  });
};

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (BannerComponent)));

/***/ }),

/***/ 5225:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ testimonialcomponent)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "reactstrap"
var external_reactstrap_ = __webpack_require__(6099);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./assets/images/testimonial/1.jpg
/* harmony default export */ const _1 = ({"src":"/_next/static/image/assets/images/testimonial/1.2e14a0676e3b5e73da6f05569ef7108e.jpg","height":600,"width":600,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAUAAEAAAAAAAAAAAAAAAAAAAAG/9oACAEBAAAAAFn/xAAUAQEAAAAAAAAAAAAAAAAAAAAC/9oACAECEAAAAF//xAAUAQEAAAAAAAAAAAAAAAAAAAAB/9oACAEDEAAAAD//xAAeEAACAQMFAAAAAAAAAAAAAAABAwIABRIEESJhcv/aAAgBAQABPwB97Qi5x0jMo5MKY9yABy88tq//xAAXEQADAQAAAAAAAAAAAAAAAAAAAREh/9oACAECAQE/AJiP/8QAFREBAQAAAAAAAAAAAAAAAAAAABH/2gAIAQMBAT8Ar//Z"});
;// CONCATENATED MODULE: ./assets/images/testimonial/2.jpg
/* harmony default export */ const _2 = ({"src":"/_next/static/image/assets/images/testimonial/2.128dd6c1580e0c9d2212a1f1fef11453.jpg","height":600,"width":600,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAUAAEAAAAAAAAAAAAAAAAAAAAE/9oACAEBAAAAAC//xAAUAQEAAAAAAAAAAAAAAAAAAAAB/9oACAECEAAAAH//xAAUAQEAAAAAAAAAAAAAAAAAAAAD/9oACAEDEAAAAF//xAAbEAADAAIDAAAAAAAAAAAAAAABAgMABAUhIv/aAAgBAQABPwBOLqH26vv0r0JrsBFAQg+mKZ//xAAXEQEBAQEAAAAAAAAAAAAAAAABAgBx/9oACAECAQE/ABSr7v/EABcRAQEBAQAAAAAAAAAAAAAAAAIBAHH/2gAIAQMBAT8AhiJ5v//Z"});
;// CONCATENATED MODULE: ./assets/images/testimonial/3.jpg
/* harmony default export */ const _3 = ({"src":"/_next/static/image/assets/images/testimonial/3.58e07d7012f0ad038da183b73c9a77bf.jpg","height":600,"width":600,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAUAAEAAAAAAAAAAAAAAAAAAAAG/9oACAEBAAAAACn/xAAUAQEAAAAAAAAAAAAAAAAAAAAE/9oACAECEAAAAF//xAAUAQEAAAAAAAAAAAAAAAAAAAAE/9oACAEDEAAAABf/xAAcEAADAAIDAQAAAAAAAAAAAAABAgMEMQAhMmH/2gAIAQEAAT8AMcQYcosgnSyKyv37XY+A65//xAAZEQACAwEAAAAAAAAAAAAAAAACAwABETL/2gAIAQIBAT8AUgCot3qf/8QAGhEAAgIDAAAAAAAAAAAAAAAAAQMAAhIhQv/aAAgBAwEBPwBrrjDfIn//2Q=="});
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/custom/sections/testimonialcomponent.js
/* eslint-disable */









const TestimonialComponent = () => {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "testimonial3 spacer ",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_reactstrap_.Container, {
        children: [/*#__PURE__*/jsx_runtime_.jsx(external_reactstrap_.Row, {
          className: "justify-content-center",
          children: /*#__PURE__*/jsx_runtime_.jsx(external_reactstrap_.Col, {
            md: "7",
            className: "text-center",
            children: /*#__PURE__*/jsx_runtime_.jsx("h2", {
              className: "title",
              children: "Veja o que nossos clientes dizem sobre n\xF3s:"
            })
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_reactstrap_.Row, {
          className: "testi3 m-t-40 justify-content-center",
          children: [/*#__PURE__*/jsx_runtime_.jsx(external_reactstrap_.Col, {
            lg: "4",
            md: "6",
            children: /*#__PURE__*/jsx_runtime_.jsx(external_reactstrap_.Card, {
              className: "card-shadow",
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_reactstrap_.CardBody, {
                children: [/*#__PURE__*/jsx_runtime_.jsx("h6", {
                  className: "font-light m-b-30",
                  children: "\u201CCum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Cras venene veliel vestibulum.\u201D"
                }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "d-flex no-block align-items-center",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                    className: "thumb-img",
                    children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                      src: _1,
                      alt: "wrapkit",
                      className: "circle"
                    })
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "m-l-20",
                    children: [/*#__PURE__*/jsx_runtime_.jsx("h6", {
                      className: "m-b-0 customer",
                      children: "Michelle Anderson"
                    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                      className: "font-10",
                      children: [/*#__PURE__*/jsx_runtime_.jsx("a", {
                        href: "",
                        className: "text-danger",
                        children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                          className: "fa fa-star"
                        })
                      }), /*#__PURE__*/jsx_runtime_.jsx("a", {
                        href: "",
                        className: "text-danger",
                        children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                          className: "fa fa-star"
                        })
                      }), /*#__PURE__*/jsx_runtime_.jsx("a", {
                        href: "",
                        className: "text-danger",
                        children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                          className: "fa fa-star"
                        })
                      }), /*#__PURE__*/jsx_runtime_.jsx("a", {
                        href: "",
                        className: "text-danger",
                        children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                          className: "fa fa-star"
                        })
                      }), /*#__PURE__*/jsx_runtime_.jsx("a", {
                        href: "",
                        className: "text-muted",
                        children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                          className: "fa fa-star"
                        })
                      })]
                    })]
                  })]
                })]
              })
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(external_reactstrap_.Col, {
            lg: "4",
            md: "6",
            children: /*#__PURE__*/jsx_runtime_.jsx(external_reactstrap_.Card, {
              className: "card-shadow",
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_reactstrap_.CardBody, {
                children: [/*#__PURE__*/jsx_runtime_.jsx("h6", {
                  className: "font-light m-b-30",
                  children: "\u201CCum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Cras venene veliel vestibulum.\u201D"
                }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "d-flex no-block align-items-center",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                    className: "thumb-img",
                    children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                      src: _2,
                      alt: "wrapkit",
                      className: "circle"
                    })
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "m-l-20",
                    children: [/*#__PURE__*/jsx_runtime_.jsx("h6", {
                      className: "m-b-0 customer",
                      children: "Mark mesty"
                    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                      className: "font-10",
                      children: [/*#__PURE__*/jsx_runtime_.jsx("a", {
                        href: "",
                        className: "text-danger",
                        children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                          className: "fa fa-star"
                        })
                      }), /*#__PURE__*/jsx_runtime_.jsx("a", {
                        href: "",
                        className: "text-danger",
                        children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                          className: "fa fa-star"
                        })
                      }), /*#__PURE__*/jsx_runtime_.jsx("a", {
                        href: "",
                        className: "text-danger",
                        children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                          className: "fa fa-star"
                        })
                      }), /*#__PURE__*/jsx_runtime_.jsx("a", {
                        href: "",
                        className: "text-danger",
                        children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                          className: "fa fa-star"
                        })
                      }), /*#__PURE__*/jsx_runtime_.jsx("a", {
                        href: "",
                        className: "text-muted",
                        children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                          className: "fa fa-star"
                        })
                      })]
                    })]
                  })]
                })]
              })
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(external_reactstrap_.Col, {
            lg: "4",
            md: "6",
            children: /*#__PURE__*/jsx_runtime_.jsx(external_reactstrap_.Card, {
              className: "card-shadow",
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_reactstrap_.CardBody, {
                children: [/*#__PURE__*/jsx_runtime_.jsx("h6", {
                  className: "font-light m-b-30",
                  children: "\u201CCum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Cras venene veliel vestibulum.\u201D"
                }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "d-flex no-block align-items-center",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                    className: "thumb-img",
                    children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                      src: _3,
                      alt: "wrapkit",
                      className: "circle"
                    })
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "m-l-20",
                    children: [/*#__PURE__*/jsx_runtime_.jsx("h6", {
                      className: "m-b-0 customer",
                      children: "Limpsy adam"
                    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                      className: "font-10",
                      children: [/*#__PURE__*/jsx_runtime_.jsx("a", {
                        href: "",
                        className: "text-danger",
                        children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                          className: "fa fa-star"
                        })
                      }), /*#__PURE__*/jsx_runtime_.jsx("a", {
                        href: "",
                        className: "text-danger",
                        children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                          className: "fa fa-star"
                        })
                      }), /*#__PURE__*/jsx_runtime_.jsx("a", {
                        href: "",
                        className: "text-danger",
                        children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                          className: "fa fa-star"
                        })
                      }), /*#__PURE__*/jsx_runtime_.jsx("a", {
                        href: "",
                        className: "text-danger",
                        children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                          className: "fa fa-star"
                        })
                      }), /*#__PURE__*/jsx_runtime_.jsx("a", {
                        href: "",
                        className: "text-muted",
                        children: /*#__PURE__*/jsx_runtime_.jsx("i", {
                          className: "fa fa-star"
                        })
                      })]
                    })]
                  })]
                })]
              })
            })
          })]
        })]
      })
    })
  });
};

/* harmony default export */ const testimonialcomponent = (TestimonialComponent);

/***/ }),

/***/ 9818:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ vistoriasection)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "reactstrap"
var external_reactstrap_ = __webpack_require__(6099);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./assets/images/staticslider/slider/hero-banner.jpg
var hero_banner = __webpack_require__(9546);
;// CONCATENATED MODULE: ./assets/images/vistoriaImage.jpg
/* harmony default export */ const vistoriaImage = ({"src":"/_next/static/image/assets/images/vistoriaImage.d8664594fbacd0d3ad46ea9d3c65facb.jpg","height":635,"width":398,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABQMBIgACEQEDEQH/xAAUAAEAAAAAAAAAAAAAAAAAAAAG/9oACAEBAAAAABn/xAAUAQEAAAAAAAAAAAAAAAAAAAAD/9oACAECEAAAAD//xAAUAQEAAAAAAAAAAAAAAAAAAAAC/9oACAEDEAAAAF//xAAcEAADAAEFAAAAAAAAAAAAAAABAwQhAAIREiL/2gAIAQEAAT8AqDK6GNoQ0sB6YPHnaca//8QAFREBAQAAAAAAAAAAAAAAAAAAABL/2gAIAQIBAT8Ap//EABURAQEAAAAAAAAAAAAAAAAAAAAR/9oACAEDAQE/AI//2Q=="});
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/custom/sections/vistoriasection.js








const VistoriaSection = () => {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "vistoria-banner-container",
      children: /*#__PURE__*/jsx_runtime_.jsx(external_reactstrap_.Container, {
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_reactstrap_.Row, {
          className: "",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(external_reactstrap_.Col, {
            md: "6",
            className: "align-self-center ",
            children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
              className: "title",
              children: "Vistoria veicular"
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("h6", {
              className: "subtitle op-8",
              children: ["A vistoria veicular \xE9 um dever de todo propriet\xE1rio de autom\xF3vel e garante o benef\xEDcio de poder circular pelas vias de todo o pa\xEDs com o seu ve\xEDculo.", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "\xC9 com a vistoria que se verifica as condi\xE7\xF5es de circula\xE7\xE3o do ve\xEDculo, bem como atesta a sua exist\xEAncia e legalidade. Assim, s\xE3o realizados procedimentos de qualidade e integridade com o objetivo de testar o funcionamento dos equipamentos que s\xE3o obrigat\xF3rios e saber se a documenta\xE7\xE3o \xE9 aut\xEAntica.", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "\xC9 pela vistoria que se pode ter a legitimidade da propriedade do ve\xEDculo."]
            }), /*#__PURE__*/jsx_runtime_.jsx("a", {
              className: "btn btn-call-to-action btn-border-radius btn-md m-t-20",
              "data-toggle": "collapse",
              href: "",
              children: /*#__PURE__*/jsx_runtime_.jsx("span", {
                children: "Agendar agora"
              })
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx(external_reactstrap_.Col, {
            md: "6",
            children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
              src: vistoriaImage,
              className: "image-vistoria-banner",
              height: 500,
              alt: "herobanner"
            })
          })]
        })
      })
    })
  });
};

/* harmony default export */ const vistoriasection = (VistoriaSection);

/***/ }),

/***/ 1873:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Find2dLocation)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);


function Find2dLocation() {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
    className: "find2DLocation",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
      className: "row find2DLocatinTitleContainer align-items-row-center",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
        className: "fas fa-map-marker-alt find2DLocatinIcon"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
        id: "find2DLocatinTitle",
        children: "Confira a \xFAnidade mais proxima de voc\xEA"
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
      id: "find2DLocatinButton",
      className: "btn-call-to-action",
      children: "Ver unidades"
    })]
  });
}

/***/ }),

/***/ 1578:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ GarantyList)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);


function GarantyList() {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
    className: "vistoriaCheckSection",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
      className: "vistoriaCheckSectionTitleContainer",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
        id: "vistoriaCheckSectionTitle",
        children: "A vistoria veicular da 2D proporciona tranquilidade e seguran\xE7a porque garante:"
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
      className: "vistoriaCheckCardContainer",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "row align-items-center-cards",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
          className: "vistoriaCheckCard",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
            className: "fa fa-check-circle iconVistoriaCheckCard"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
            className: "vistoriaCheckCardTitle",
            children: "Autenticidade da documenta\xE7\xE3o"
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
          className: "vistoriaCheckCard",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
            className: "fa fa-check-circle iconVistoriaCheckCard"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
            className: "vistoriaCheckCardTitle max-width-small",
            children: "Legitimidade da propriedade"
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
          className: "vistoriaCheckCard",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
            className: "fa fa-check-circle iconVistoriaCheckCard"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
            className: "vistoriaCheckCardTitle",
            children: "Funcionamento dos equipamentos"
          })]
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "row align-items-center-cards div-margin-bottom",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
          className: "vistoriaCheckCard",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
            className: "fa fa-check-circle iconVistoriaCheckCard"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
            className: "vistoriaCheckCardTitle max-width-small",
            children: "Identidade da identifica\xE7\xE3o"
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
          className: "vistoriaCheckCard",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
            className: "fa fa-check-circle iconVistoriaCheckCard"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
            className: "vistoriaCheckCardTitle max-width-small",
            children: "Condi\xE7\xF5es de circula\xE7\xE3o de ve\xEDculo"
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
          className: "vistoriaCheckCard",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
            className: "fa fa-check-circle iconVistoriaCheckCard"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
            className: "vistoriaCheckCardTitle",
            children: "Regulariza\xE7\xE3o e transfer\xEAncia veicular"
          })]
        })]
      })]
    })]
  });
}

/***/ }),

/***/ 1480:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ListIcon)
/* harmony export */ });
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(799);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);



function ListIcon() {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
    className: "list-section",
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
      className: "container",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
        className: "row",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
          className: "col-lg-4 col-md-6 mb-4 mb-lg-0",
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
            className: "list-box d-flex align-items-center",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
              className: "list-icon",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("i", {
                className: "fa fa-check-circle"
              })
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
              className: "content",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("h3", {
                children: "Segura\xE7a"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("p", {
                children: "Para quem vende"
              })]
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
          className: "col-lg-4 col-md-6 mb-4 mb-lg-0",
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
            className: "list-box d-flex align-items-center",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
              className: "list-icon",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("i", {
                className: "fa fa-check-circle"
              })
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
              className: "content",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("h3", {
                children: "Tranquilidade"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("p", {
                children: "Para quem compra"
              })]
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
          className: "col-lg-4 col-md-6",
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
            className: "list-box d-flex justify-content-start align-items-center",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
              className: "list-icon",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("i", {
                className: "fa fa-check-circle"
              })
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
              className: "content",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("h3", {
                children: "Satisfa\xE7\xE3o"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("p", {
                children: "Para todos"
              })]
            })]
          })
        })]
      })
    })
  });
}

/***/ }),

/***/ 9546:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/image/assets/images/staticslider/slider/hero-banner.a060502203c201206eaac7b4c04f60f8.jpg","height":635,"width":506,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABgMBIgACEQEDEQH/xAAUAAEAAAAAAAAAAAAAAAAAAAAG/9oACAEBAAAAAGf/xAAUAQEAAAAAAAAAAAAAAAAAAAAF/9oACAECEAAAADf/xAAUAQEAAAAAAAAAAAAAAAAAAAAF/9oACAEDEAAAAGv/xAAaEAEBAAIDAAAAAAAAAAAAAAACAQADBBGh/9oACAEBAAE/ABdw5G4o1BdMryzP/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwB//9k="});

/***/ })

};
;